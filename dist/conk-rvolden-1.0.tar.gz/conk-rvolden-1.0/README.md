# conk
Cython Smith-Waterman aligner for C3POa
